module.exports = {
    guildId: '1189620182298144850',
    logChannelId: '1184272075792318534',
    applicationChannelId: '1184335492456652850',
    countChannelId: '1184356506636914738',
    levelupChannelId: '1181784372181999707',
    berichtenLogChannelId: '1184272075792318534',
    picperms: '1188116466009116783',
    primaryColor: '#5865F2',
    welcomeChannelId: '1189620183044718755'
};