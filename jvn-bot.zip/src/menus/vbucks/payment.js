const { ModalBuilder, StringSelectMenuOptionBuilder, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');

module.exports = {
    id: 'padddyment',
    permissions: [],
    run: async (client, interaction) => {
        interaction.deferUpdate();
        

        


    },
}
