const { ModalBuilder, StringSelectMenuOptionBuilder, StringSelectMenuBuilder, ActionRowBuilder } = require('discord.js');

module.exports = {
    id: 'sddbucks',
    permissions: [],
    run: async (client, interaction) => {

        interaction.deferUpdate();
        

    },
}
